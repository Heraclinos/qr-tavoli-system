module.exports = {
  JWT_SECRET: process.env.JWT_SECRET || 'your-secret-key-change-in-production',
  JWT_EXPIRE: process.env.JWT_EXPIRE || '24h',

  // Configurazioni QR
  QR_CODE_PREFIX: 'TABLE_',
  MAX_POINTS_PER_TRANSACTION: 100,
  MIN_POINTS_PER_TRANSACTION: 1,

  // Configurazioni tavoli
  MAX_TABLES: 50,
  DEFAULT_TABLE_POINTS: 0,

  // Ruoli utente
  USER_ROLES: {
    CUSTOMER: 'customer',
    CASHIER: 'cashier',
    ADMIN: 'admin'
  },

  // Rate limiting
  RATE_LIMIT: {
    windowMs: 15 * 60 * 1000, // 15 minuti
    max: 100 // max 100 richieste per IP per finestra
  },

  // Configurazioni database
  DB_OPTIONS: {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    maxPoolSize: 10,
    serverSelectionTimeoutMS: 5000,
    socketTimeoutMS: 45000,
  }
};